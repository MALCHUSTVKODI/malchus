import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, xbmcaddon
import urlresolver
from addon.common.addon import Addon
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.pinoyteleserye'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'pinoyteleserye'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"
BASEURL = 'http://www.pinoyhdreplay.su/'


def MENU():
    addDir('[B][COLOR white]PinoyHD Replay[/COLOR][/B]','url',60,ART + 'reply.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]KAPUSO SHOWS[/COLOR][/B]','http://www.kapuso.me/search/label/GMA?&max-results=24',5,ART + 'kapus.jpg',FANART,'')
    addDir('[B][COLOR white]KAPAMILYA SHOWS[/COLOR][/B]','http://pacitalaflakes.blogspot.com/search/label/ABS-CBN?m=0',5,ART + 'tamb.jpg',FANART,'')
    addDir('[B][COLOR white]ABS-CBN SHOWS/GMA SHOWS[/COLOR][/B]','http://www.lambingan.cn/',30,ART + 'lambing.jpg',FANART,'')
    addDir('[B][COLOR white]CinePinoy[/COLOR][/B]','http://www.cinepinoy.lol/videos/',20,ART + 'movies.jpg',ART + 'fanart2.jpg','')
    setView('tvshows', 'tvshows-view')

def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile("<a class='thumbx' href='(.+?)' title='(.+?)'.+?src='(.+?)'/></a>",re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&amp;#038;','&')
        icon = icon.replace('s72-c/','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    np = re.compile("<a class='blog-pager-older-link' href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
        if 'kapuso' in url:
            icon = ART + 'nextpagekap.jpg'
        if 'pacitalaflakes' in url:
            icon = ART + 'nextpagetamb.jpg'
        addDir('[B][COLOR red]Older Posts>>>[/COLOR][/B]',url,5,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<[iI][fF][rR][aA][mM][eE] [sS][rR][cC]="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
        try:
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()
        except:pass
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    altlinks = re.compile('DM.player.+?"player(.+?)".+?video: "(.+?)"',re.DOTALL).findall(OPEN)
    for name2,url in altlinks:
        addDir('[B][COLOR white]Part %s[/COLOR][/B]' %name2,'http://www.dailymotion.com/embed/video/%s'%url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')

###############cinepinoy########### 
def Mov_Menu(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="videopost">.+?href="(.+?)".+?title="(.+?)".+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
        name=name.replace('Permanent Link to ','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,50,icon,ART + 'fanart2.jpg','')
    np = re.compile("class='pagination'.+?class='current'.+?href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,20,ART + 'next_movs.jpg',ART + 'fanart2.jpg','')
    xbmc.executebuiltin('Container.SetViewMode(500)')    
    
 

def RES_mov(url):
    try:
        OPEN = Open_Url(url)
        dialog = xbmcgui.Dialog()
        servers = dialog.yesno('LINKS', 'Please Choose your Link', yeslabel='Openload', nolabel='TheVideo')
        if servers:
            url = re.compile('"https://openload.io/embed/(.+?)"',re.DOTALL).findall(OPEN)[0]
            url = 'https://openload.co/embed/' + url
            stream_url=urlresolver.HostedMediaFile(url).resolve()

        else:
            url = re.compile('"http://thevideo.me/(.+?)"',re.DOTALL).findall(OPEN)[0]
            url = 'http://thevideo.me/' + url
            stream_url=urlresolver.HostedMediaFile(url).resolve()
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:pass    

    
############### lambingan.########### 
def lamb_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="post-header"><h3><a title="(.+?)" href="(.+?)".+?<img width="181" height="120" src="(.+?)"',re.DOTALL).findall(OPEN)
    for name,url,icon in Regex:
        icon = 'http:' + icon
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,35,icon,FANART,'')
    np = re.compile('class="next page-numbers" href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,30,ART + 'lampnp.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')     
    
def lamb_vids(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<iframe frameborder="0".+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
        if 'http:' not in url:
            url = 'http:' + url
        if '/dm-' in url:
            name2 = 'Main Link [COLOR blue](Dailymotion)[/COLOR]'
        elif '/mo-'in url:
            name2 = 'Main Link [COLOR cyan](Openload)[/COLOR]'
        elif '/all-'in url:
            name2 = 'Main Link [COLOR yellow](Estream)[/COLOR]'
        else:
            name2= 'Short Clip'
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,40,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)') 

def lamb_res(url):
    if 'watchnew.asia' in url:
        OPEN = Open_Url(url)
        try:
            url = re.compile('<[iI][fF][rR][aA][mM][eE].+?[sS][rR][cC]="(.+?)"',re.DOTALL).findall(OPEN)[0]
            if 'http:' not in url:
                url = 'http:' + url
                stream_url = urlresolver.resolve(url)
            else:
                stream_url = urlresolver.resolve(url)
        except:
            url = re.compile('<div class=\'container\'.+?href="(.+?)"',re.DOTALL).findall(OPEN)[0]
            stream_url = urlresolver.resolve(url)

    else:
        stream_url = urlresolver.resolve(url)
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(stream_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

    
######################## pinoyhdreplay###############  
def PHD_menu():
    addDir('[B][COLOR white]Recent Videos[/COLOR][/B]',BASEURL,65,ART + 'rep_rec.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]TeleSerye[/COLOR][/B]',BASEURL,61,ART + 'rep_tele.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]Weekdays[/COLOR][/B]',BASEURL,62,ART + 'rep_days.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]Weekends[/COLOR][/B]',BASEURL,63,ART + 'rep_ends.jpg',ART + 'fanart2.jpg','')
    setView('tvshows', 'tvshows-view')    
 
def PHD_ts(url):
    OPEN = Open_Url(url)
    Regex = re.compile('>TELESERYE<(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile("<a href='(.+?)'>(.+?)</a>",re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,65,ART + 'rep_tele.jpg',ART + 'fanart2.jpg','')
    xbmc.executebuiltin('Container.SetViewMode(50)')  

def PHD_wdys(url):
    OPEN = Open_Url(url)
    Regex = re.compile('>WEEKDAYS<(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile("<a href='(.+?)'>(.+?)</a>",re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,65,ART + 'rep_days.jpg',ART + 'fanart2.jpg','')
    xbmc.executebuiltin('Container.SetViewMode(50)')  

def PHD_wends(url):
    OPEN = Open_Url(url)
    Regex = re.compile('>WEEKENDS<(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile("<a href='(.+?)'>(.+?)</a>",re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,65,ART + 'rep_ends.jpg',ART + 'fanart2.jpg','')
    xbmc.executebuiltin('Container.SetViewMode(50)')  

def PHD_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile("<h2 class='post-title entry-title'>.+?href='(.+?)'>(.+?)</a>.+?src=\"(.+?)\"",re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,68,icon,ART + 'fanart2.jpg','')
    np = re.compile("class='blog-pager-older-link' href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,65,ART + 'rep_np.jpg',ART + 'fanart2.jpg','')
    xbmc.executebuiltin('Container.SetViewMode(50)')       

def PHD_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('iframe.+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
        if urlresolver.HostedMediaFile(url):
            if 'openload' not in url:
               name2 = url.split('//')[1].replace('www.','')
               name2 = name2.split('/')[0].split('.')[0].title() 
               name2 = name2.replace('Userscloud','Userscloud [COLOR red](Debrid)[/COLOR]')
               addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,ART + 'fanart2.jpg',name)
    downs = re.compile('href="http(.+?)"',re.DOTALL).findall(OPEN)
    for url in downs:
        url='http' + url
        if urlresolver.HostedMediaFile(url):
               name2 = url.split('//')[1].replace('www.','')
               name2 = name2.split('/')[0].split('.')[0].title() 
               name2 = name2.replace('Userscloud','Userscloud [COLOR red](Debrid)[/COLOR]')
               addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,ART + 'fanart2.jpg',name)
    try:
        altRegex = re.compile('src="//www.dailymotion.com/(.+?)"',re.DOTALL).findall(OPEN)
        for url in altRegex:
            url = 'http://www.dailymotion.com/' + url 
            addDir('[B][COLOR white]Dialymotion Clip[/COLOR][/B]',url,100,iconimage,ART + 'fanart2.jpg',name)
    except:pass            
###############################   
def RESOLVE(url):
    try:
        if 'speedvid.net' in url:
            OPEN = Open_Url(url)
            link = re.compile('primary\|8777\|.+?primary\|(.+?)\|(.+?)\|.+?image\|mp4\|(.+?)\|',re.DOTALL).findall(OPEN)
            for port,server,hash in link:
                url = 'http://'+ server +'.speedvid.net:'+port+'/'+hash+'/v.mp4'
            stream_url=url
        else:
            stream_url = urlresolver.resolve(url)
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:pass

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link

    
    
def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100 or mode==50 or mode==40:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def setView(content, viewType):
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if addon.get_setting('auto-view') == 'true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.get_setting(viewType) )
    
params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None




try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage=urllib.unquote_plus(params["iconimage"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass
try:
	description=urllib.unquote_plus(params["description"])
except:
	pass

if mode==None or url==None or len(url)<1 : MENU()
elif mode == 5 : Get_content(url) 
elif mode == 10 : Get_links(name,url)
elif mode == 20 : Mov_Menu(url)
elif mode == 30 : lamb_content(url)
elif mode == 35 : lamb_vids(name,url)
elif mode == 40 : lamb_res(url)
elif mode == 50 : RES_mov(url) 
elif mode == 60 : PHD_menu()
elif mode == 61 : PHD_ts(url)
elif mode == 62 : PHD_wdys(url)
elif mode == 63 : PHD_wends(url)
elif mode == 65 : PHD_content(url)
elif mode == 68 : PHD_links(name,url)
elif mode ==100: RESOLVE(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))

















